package com.inforcap.sistemaclientes.main;

import com.inforcap.sistemaclientes.vista.Menu;

public class Main {

    public static void main(String[] args) {

        Menu menu = new Menu();
            menu.iniciarMenu();

        // ExportadorCsv exportadorCsv = new ExportadorCsv();
        // ClienteServicio clienteServicio = new ClienteServicio();
        // ArchivoServicio archivoServicio = new ArchivoServicio(exportadorCsv, clienteServicio);
        // archivoServicio.exportar("ListaCliente", null);
        // if(!exportadorCsv.getStatusExported()){
        //     System.out.println(exportadorCsv.getStatusMessage());
        // }
    }
}
