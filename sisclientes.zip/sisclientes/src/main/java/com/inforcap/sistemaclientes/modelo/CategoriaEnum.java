package com.inforcap.sistemaclientes.modelo;

public enum CategoriaEnum {
    ACTIVO,   
    INACTIVO
}
